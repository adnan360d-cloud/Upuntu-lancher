package com.example

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

data class AppInfo(
    val name: String,
    val packageName: String,
    val icon: Drawable,
    val customIconUri: String?,
    val intent: Intent?
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps

    private val _openApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val openApps: StateFlow<List<AppInfo>> = _openApps

    private val _customFontPath = MutableStateFlow<String?>(prefs.getString("custom_font_path", null))
    val customFontPath: StateFlow<String?> = _customFontPath

    init {
        loadApps()
    }

    fun loadApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val pm = getApplication<Application>().packageManager
            
            val utStoreApp = AppInfo(
                name = "Ubuntu Store",
                packageName = "com.ubuntu.store.fake",
                icon = android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT),
                customIconUri = null,
                intent = null
            )
            
            val intent = Intent(Intent.ACTION_MAIN, null)
            intent.addCategory(Intent.CATEGORY_LAUNCHER)

            val resolveInfos = pm.queryIntentActivities(intent, 0)
            val appList = resolveInfos.mapNotNull { resolveInfo ->
                val packageName = resolveInfo.activityInfo.packageName
                // Do not include our own launcher in the list
                if (packageName == getApplication<Application>().packageName) {
                    return@mapNotNull null
                }
                
                val customIconUri = prefs.getString("icon_$packageName", null)
                
                AppInfo(
                    name = resolveInfo.loadLabel(pm).toString(),
                    packageName = packageName,
                    icon = resolveInfo.loadIcon(pm),
                    customIconUri = customIconUri,
                    intent = pm.getLaunchIntentForPackage(packageName)
                )
            }.sortedBy { it.name.lowercase() }

            _apps.value = listOf(utStoreApp) + appList
            _openApps.value = appList.shuffled().take(6)
        }
    }

    fun setCustomIcon(packageName: String, uri: Uri?) {
        if (uri == null) {
            prefs.edit().remove("icon_$packageName").apply()
        } else {
            val localPath = copyUriToLocal(uri, "icon_$packageName")
            if (localPath != null) {
                prefs.edit().putString("icon_$packageName", localPath).apply()
            }
        }
        loadApps()
    }

    fun setCustomFont(uri: Uri?) {
        if (uri == null) {
            prefs.edit().remove("custom_font_path").apply()
            _customFontPath.value = null
        } else {
            val localPath = copyUriToLocal(uri, "custom_font.ttf")
            if (localPath != null) {
                prefs.edit().putString("custom_font_path", localPath).apply()
                _customFontPath.value = localPath
            }
        }
    }

    private fun copyUriToLocal(uri: Uri, fileName: String): String? {
        return try {
            val context = getApplication<Application>()
            val file = File(context.filesDir, fileName)
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val outputStream = FileOutputStream(file)
            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
