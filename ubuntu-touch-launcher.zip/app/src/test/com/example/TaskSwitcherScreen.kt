package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TaskSwitcherScreen(viewModel: LauncherViewModel, onBack: () -> Unit) {
    val openApps by viewModel.openApps.collectAsState()
    val context = LocalContext.current
    
    val aubergineBg = Color(0xFF2C001E)
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(aubergineBg)
    ) {
        Box(modifier = Modifier.fillMaxSize().clickable { onBack() })
        
        if (openApps.isEmpty()) {
            Text(
                text = "No open apps",
                color = Color.White.copy(alpha = 0.5f),
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            LazyRow(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy((-60).dp),
                contentPadding = PaddingValues(horizontal = 60.dp, vertical = 100.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(openApps) { app ->
                    Column(
                        modifier = Modifier
                            .graphicsLayer {
                                rotationY = -35f
                                cameraDistance = 12f * density
                                scaleY = 0.9f
                                scaleX = 0.9f
                            }
                            .width(220.dp)
                            .height(400.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.DarkGray)
                            .clickable {
                                app.intent?.let { context.startActivity(it) }
                                onBack()
                            },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Mock app preview
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color.White)
                        ) {
                            AppIconView(
                                app = app,
                                modifier = Modifier
                                    .size(64.dp)
                                    .align(Alignment.Center)
                            )
                        }
                        // Bottom bar with app name
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.8f))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = app.name,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
