package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun UbuntuLauncherScreen(viewModel: LauncherViewModel, onNavigate: (ScreenType) -> Unit) {
    val apps by viewModel.apps.collectAsState()
    val context = LocalContext.current

    val aubergineBg = Color(0xFF2C001E)
    val ubuntuOrange = Color(0xFFE95420)
    val ubuntuPurple = Color(0xFF772953)
    val defaultText = Color(0xFFF1F5F9)

    var showSidebar by remember { mutableStateOf(false) }
    var showNotifications by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    BackHandler(enabled = showSidebar || showNotifications) {
        if (showNotifications) showNotifications = false
        else if (showSidebar) showSidebar = false
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(aubergineBg)
    ) {
        // --- 1. Main Viewport (App Grid & fake status bar) ---
        Column(modifier = Modifier.fillMaxSize()) {
            // Fake Status Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp)
                    .background(Color.Black.copy(alpha = 0.2f))
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Ubuntu Touch", color = defaultText.copy(alpha = 0.8f), fontSize = 10.sp, fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Wifi, contentDescription = null, tint = defaultText, modifier = Modifier.size(12.dp))
                    Icon(Icons.Default.BatteryFull, contentDescription = null, tint = defaultText, modifier = Modifier.size(12.dp))
                    Text("12:45", color = defaultText.copy(alpha = 0.8f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Environment Toggle Badge
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF4ADE80).copy(alpha = pulseAlpha)))
                    Column {
                        Text("PROOT CONTAINER", color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text("X11 Server Active • Ubuntu 20.04", color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp)
                    }
                }
                Box(
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(ubuntuOrange).clickable { onNavigate(ScreenType.SETTINGS) }.padding(horizontal = 12.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("SETTINGS", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            // App Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(4), // slightly denser
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(apps) { app ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                if (app.packageName == "com.ubuntu.store.fake") {
                                    onNavigate(ScreenType.STORE)
                                } else {
                                    app.intent?.let { context.startActivity(it) }
                                }
                            }
                            .padding(vertical = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            AppIconView(app = app, modifier = Modifier.fillMaxSize())
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = app.name,
                            color = defaultText,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // --- 2. Notifications Center (Swipe from top) ---
        AnimatedVisibility(
            visible = showNotifications,
            enter = slideInVertically(initialOffsetY = { -it }),
            exit = slideOutVertically(targetOffsetY = { -it }),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF111111).copy(alpha = 0.95f))
                    .padding(bottom = 16.dp)
            ) {
                // Ubuntu touch style indicators header
                Row(
                    modifier = Modifier.fillMaxWidth().height(48.dp).background(Color.White.copy(alpha = 0.05f)),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = Color.Gray)
                    Icon(Icons.Default.Bluetooth, contentDescription = "Bluetooth", tint = Color.Gray)
                    Icon(Icons.Default.Wifi, contentDescription = "Network", tint = ubuntuOrange)
                    Icon(Icons.Default.VolumeUp, contentDescription = "Sound", tint = Color.Gray)
                    Icon(Icons.Default.BatteryFull, contentDescription = "Battery", tint = Color.Gray)
                }
                
                // Content of active indicator
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("Wi-Fi Settings", color = ubuntuOrange, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Connected to Network", color = Color.White)
                        Switch(checked = true, onCheckedChange = {})
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("System Settings...", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.clickable { onNavigate(ScreenType.SETTINGS) })
                }
                
                Box(modifier = Modifier.fillMaxWidth().clickable { showNotifications = false }.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                    Box(modifier = Modifier.width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color.Gray))
                }
            }
        }

        // --- 3. Left Launcher Dock ---
        AnimatedVisibility(
            visible = showSidebar,
            enter = slideInHorizontally(initialOffsetX = { -it }),
            exit = slideOutHorizontally(targetOffsetX = { -it }),
            modifier = Modifier.align(Alignment.CenterStart)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(72.dp)
                    .background(Color.Black.copy(alpha = 0.85f))
                    .padding(vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(brush = Brush.linearGradient(colors = listOf(ubuntuOrange, ubuntuPurple))).clickable { showSidebar = false },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Apps, contentDescription = "Dash", tint = Color.White, modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.height(20.dp))
                // Top 5 apps
                apps.take(5).forEach { app ->
                    val isStore = app.packageName == "com.ubuntu.store.fake"
                    Box(
                        modifier = Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.1f)).clickable { 
                            if(isStore) onNavigate(ScreenType.STORE)
                            else app.intent?.let { context.startActivity(it) }
                            showSidebar = false 
                        },
                        contentAlignment = Alignment.Center
                    ) {
                        AppIconView(app = app, modifier = Modifier.fillMaxSize())
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // Tap outside overlays to close
        if (showSidebar) {
           Box(modifier = Modifier.fillMaxSize().padding(start = 72.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { showSidebar = false })
        }
        if (showNotifications) {
           Box(modifier = Modifier.fillMaxSize().padding(top = 250.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { showNotifications = false })
        }

        // --- 4. Gesture Interceptors (High invisible overlays) ---
        // Top Edge -> Notifications
        Box(
            modifier = Modifier.fillMaxWidth().height(24.dp).align(Alignment.TopCenter)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount -> if (dragAmount > 10) showNotifications = true }
                }
        )
        // Left Edge -> Dock
        Box(
            modifier = Modifier.fillMaxHeight().width(24.dp).align(Alignment.CenterStart)
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { _, dragAmount -> if (dragAmount > 10) showSidebar = true }
                }
        )
        // Right Edge -> Task Switcher
        Box(
            modifier = Modifier.fillMaxHeight().width(24.dp).align(Alignment.CenterEnd)
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { _, dragAmount -> if (dragAmount < -10) onNavigate(ScreenType.TASKS) }
                }
        )
    }
}

@Composable
fun AppIconView(app: AppInfo, modifier: Modifier = Modifier) {
    if (app.packageName == "com.ubuntu.store.fake") {
        Box(
            modifier = modifier.background(Color(0xFFE95420), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.ShoppingCart, contentDescription = "Store", tint = Color.White, modifier = Modifier.size(24.dp))
        }
        return
    }

    if (app.customIconUri != null) {
        val customBitmap = remember(app.customIconUri) {
            try { BitmapFactory.decodeFile(app.customIconUri) } catch (e: Exception) { null }
        }
        if (customBitmap != null) {
            Image(bitmap = customBitmap.asImageBitmap(), contentDescription = app.name, modifier = modifier, contentScale = ContentScale.Crop)
            return
        }
    }

    val bitmap = remember(app.packageName) { drawableToBitmap(app.icon) }

    if (bitmap != null) {
        Image(bitmap = bitmap.asImageBitmap(), contentDescription = app.name, modifier = modifier, contentScale = ContentScale.Fit)
    } else {
        Box(modifier = modifier.background(Color.Gray, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
            Text(app.name.take(1), color = Color.White)
        }
    }
}

fun drawableToBitmap(drawable: Drawable): Bitmap? {
    if (drawable is BitmapDrawable) {
        if (drawable.bitmap != null) return drawable.bitmap
    }
    val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 144
    val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 144
    return try {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        bitmap
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
