package com.example

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: LauncherViewModel, onBack: () -> Unit) {
    val apps by viewModel.apps.collectAsState()

    var selectedAppForIcon by remember { mutableStateOf<String?>(null) }
    
    val fontPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        viewModel.setCustomFont(uri)
    }

    val iconPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        selectedAppForIcon?.let { packageName ->
            viewModel.setCustomIcon(packageName, uri)
        }
        selectedAppForIcon = null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ubuntu Launcher Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF2C001E),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF1F5F9))
        ) {
            item {
                Text(
                    text = "Appearance",
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(16.dp)
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Change System Font") },
                    supportingContent = { Text("Select a TTF/OTF file from storage") },
                    leadingContent = {
                        Icon(Icons.Default.FontDownload, contentDescription = null, tint = Color(0xFFE95420))
                    },
                    modifier = Modifier.clickable {
                        fontPicker.launch(arrayOf("*/*"))
                    }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Reset Font") },
                    modifier = Modifier.clickable {
                        viewModel.setCustomFont(null)
                    }
                )
            }
            
            item {
                Text(
                    text = "Custom App Icons",
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 8.dp)
                )
            }
            
            items(apps) { app ->
                ListItem(
                    headlineContent = { Text(app.name) },
                    supportingContent = { Text(app.packageName) },
                    leadingContent = {
                        AppIconView(app = app, modifier = Modifier.size(40.dp).clip(CircleShape))
                    },
                    trailingContent = {
                        Row {
                            if (app.customIconUri != null) {
                                TextButton(onClick = { viewModel.setCustomIcon(app.packageName, null) }) {
                                    Text("Reset")
                                }
                            }
                            TextButton(onClick = {
                                selectedAppForIcon = app.packageName
                                iconPicker.launch(arrayOf("image/*"))
                            }) {
                                Text("Change")
                            }
                        }
                    }
                )
            }
        }
    }
}
