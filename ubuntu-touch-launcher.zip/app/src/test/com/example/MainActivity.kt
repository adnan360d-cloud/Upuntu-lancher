package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.ui.theme.MyApplicationTheme
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File

enum class ScreenType {
    HOME, SETTINGS, STORE, TASKS
}

class MainActivity : ComponentActivity() {
  private val viewModel: LauncherViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    WindowCompat.setDecorFitsSystemWindows(window, false)
    WindowInsetsControllerCompat(window, window.decorView).apply {
        hide(WindowInsetsCompat.Type.systemBars())
        systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
    enableEdgeToEdge()
    setContent {
        val currentScreen = remember { mutableStateOf(ScreenType.HOME) }
        val customFontPath by viewModel.customFontPath.collectAsState()
        
        val customFontFamily = remember(customFontPath) {
            if (customFontPath != null && File(customFontPath!!).exists()) {
                try {
                    val typeface = android.graphics.Typeface.createFromFile(customFontPath!!)
                    androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Typeface(typeface))
                } catch (e: Exception) {
                    androidx.compose.ui.text.font.FontFamily.Default
                }
            } else {
                androidx.compose.ui.text.font.FontFamily.Default
            }
        }
        
        val defaultTypography = MaterialTheme.typography
        val typography = Typography(
            displayLarge = defaultTypography.displayLarge.copy(fontFamily = customFontFamily),
            displayMedium = defaultTypography.displayMedium.copy(fontFamily = customFontFamily),
            displaySmall = defaultTypography.displaySmall.copy(fontFamily = customFontFamily),
            headlineLarge = defaultTypography.headlineLarge.copy(fontFamily = customFontFamily),
            headlineMedium = defaultTypography.headlineMedium.copy(fontFamily = customFontFamily),
            headlineSmall = defaultTypography.headlineSmall.copy(fontFamily = customFontFamily),
            titleLarge = defaultTypography.titleLarge.copy(fontFamily = customFontFamily),
            titleMedium = defaultTypography.titleMedium.copy(fontFamily = customFontFamily),
            titleSmall = defaultTypography.titleSmall.copy(fontFamily = customFontFamily),
            bodyLarge = defaultTypography.bodyLarge.copy(fontFamily = customFontFamily),
            bodyMedium = defaultTypography.bodyMedium.copy(fontFamily = customFontFamily),
            bodySmall = defaultTypography.bodySmall.copy(fontFamily = customFontFamily),
            labelLarge = defaultTypography.labelLarge.copy(fontFamily = customFontFamily),
            labelMedium = defaultTypography.labelMedium.copy(fontFamily = customFontFamily),
            labelSmall = defaultTypography.labelSmall.copy(fontFamily = customFontFamily)
        )

      MyApplicationTheme {
        MaterialTheme(typography = typography) {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                BackHandler(currentScreen.value != ScreenType.HOME) {
                    currentScreen.value = ScreenType.HOME
                }
                
                Crossfade(targetState = currentScreen.value, label = "screen_transition") { screen ->
                    when (screen) {
                        ScreenType.HOME -> UbuntuLauncherScreen(viewModel, { currentScreen.value = it })
                        ScreenType.SETTINGS -> SettingsScreen(viewModel, { currentScreen.value = ScreenType.HOME })
                        ScreenType.STORE -> UbuntuStoreScreen({ currentScreen.value = ScreenType.HOME })
                        ScreenType.TASKS -> TaskSwitcherScreen(viewModel, { currentScreen.value = ScreenType.HOME })
                    }
                }
            }
        }
      }
    }
  }
}

